1) Android Studio > Open > پوشه ServiceRequests (Gradle sync خودکار)
2) Run روی گوشی خدماتی (اینترنت فقط برای دانلود اولیه کتابخانه‌ها لازم است)
3) اجازه Notification و خاموش کردن Battery optimization را بدهید
4) در تنظیمات مودم برای گوشی خدماتی IP ثابت (DHCP Reservation) بگذارید
5) روی آیفون‌ها در Safari آدرس نمایش‌داده‌شده در اپ را باز کنید و Add to Home Screen بزنید
