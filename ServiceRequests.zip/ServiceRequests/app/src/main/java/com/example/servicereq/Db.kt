package com.example.servicereq

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Row(val id: Long, val sender: String, val body: String, val created: Long, val status: String)

class Db private constructor(c: Context) : SQLiteOpenHelper(c, "requests.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE requests(id INTEGER PRIMARY KEY AUTOINCREMENT, sender TEXT, " +
                "body TEXT, created INTEGER, status TEXT DEFAULT 'new')"
        )
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    @Synchronized fun add(sender: String, body: String): Long {
        val v = ContentValues().apply {
            put("sender", sender); put("body", body)
            put("created", System.currentTimeMillis()); put("status", "new")
        }
        return writableDatabase.insert("requests", null, v)
    }

    @Synchronized fun setStatus(id: Long, status: String) {
        val v = ContentValues().apply { put("status", status) }
        writableDatabase.update("requests", v, "id=?", arrayOf(id.toString()))
    }

    @Synchronized fun list(sender: String? = null): List<Row> {
        val out = ArrayList<Row>()
        val c = if (sender == null)
            readableDatabase.rawQuery("SELECT id,sender,body,created,status FROM requests ORDER BY id DESC LIMIT 200", null)
        else
            readableDatabase.rawQuery("SELECT id,sender,body,created,status FROM requests WHERE sender=? ORDER BY id DESC LIMIT 100", arrayOf(sender))
        c.use { while (it.moveToNext()) out.add(Row(it.getLong(0), it.getString(1), it.getString(2), it.getLong(3), it.getString(4))) }
        return out
    }

    companion object {
        @Volatile private var inst: Db? = null
        fun get(c: Context): Db = inst ?: synchronized(this) { inst ?: Db(c.applicationContext).also { inst = it } }
    }
}
