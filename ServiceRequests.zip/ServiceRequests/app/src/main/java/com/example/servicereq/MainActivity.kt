package com.example.servicereq

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var db: Db
    private lateinit var addr: TextView
    private lateinit var adapter: ArrayAdapter<String>
    private var rows: List<Row> = emptyList()
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 3000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = Db.get(this)
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        addr = TextView(this).apply { textSize = 18f; gravity = Gravity.CENTER }
        val bat = Button(this).apply {
            text = "خاموش کردن بهینه‌سازی باتری (مهم)"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }
        }
        val list = ListView(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList<String>())
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val r = rows[pos]
            AlertDialog.Builder(this).setTitle(r.sender).setMessage(r.body)
                .setPositiveButton("انجام شد") { _, _ -> db.setStatus(r.id, "done"); refresh() }
                .setNeutralButton("دیده شد") { _, _ -> db.setStatus(r.id, "seen"); refresh() }
                .setNegativeButton("بستن", null).show()
        }
        root.addView(addr); root.addView(bat)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        ServerService.start(this)
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun ip(): String {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val i = wm.connectionInfo.ipAddress
        if (i == 0) return "به وای‌فای وصل نیستید"
        return "${i and 255}.${i shr 8 and 255}.${i shr 16 and 255}.${i shr 24 and 255}"
    }

    private fun refresh() {
        addr.text = "آدرس برای پرسنل:\nhttp://" + ip() + ":8080"
        rows = db.list()
        val f = SimpleDateFormat("HH:mm", Locale.getDefault())
        val st = mapOf("new" to "🟠 جدید", "seen" to "🔵 دیده شد", "done" to "🟢 انجام شد")
        adapter.clear()
        adapter.addAll(rows.map { "${st[it.status]}  ${it.sender} (${f.format(Date(it.created))})\n${it.body}" })
    }
}
