package com.example.servicereq

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import fi.iki.elonen.NanoHTTPD
import org.json.JSONArray
import org.json.JSONObject

class ServerService : Service() {
    private var server: Web? = null
    private lateinit var db: Db

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        db = Db.get(this)
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("svc", "سرویس", NotificationManager.IMPORTANCE_LOW))
            val ch = NotificationChannel("req", "درخواست‌ها", NotificationManager.IMPORTANCE_HIGH)
            ch.enableVibration(true)
            nm.createNotificationChannel(ch)
        }
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "svc")
            .setContentTitle("سرور درخواست‌ها فعال است")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open).build()
        startForeground(1, n)
        if (server == null) {
            server = Web().also { it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false) }
        }
        return START_STICKY
    }

    override fun onDestroy() { server?.stop(); server = null; super.onDestroy() }

    private fun notifyNew(id: Long, sender: String, body: String) {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "req")
            .setContentTitle("درخواست جدید از " + sender)
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentIntent(open).setAutoCancel(true).build()
        getSystemService(NotificationManager::class.java).notify((id + 100).toInt(), n)
    }

    private fun json(status: NanoHTTPD.Response.Status, o: Any) =
        NanoHTTPD.newFixedLengthResponse(status, "application/json; charset=utf-8", o.toString())

    inner class Web : NanoHTTPD(8080) {
        override fun serve(s: IHTTPSession): Response = try {
            when {
                s.uri == "/" -> newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", PAGE)
                s.uri == "/api/request" && s.method == Method.POST -> {
                    val len = s.headers["content-length"]?.toIntOrNull() ?: 0
                    val buf = ByteArray(len)
                    var off = 0
                    while (off < len) {
                        val r = s.inputStream.read(buf, off, len - off)
                        if (r < 0) break
                        off += r
                    }
                    val j = JSONObject(String(buf, 0, off, Charsets.UTF_8))
                    val sender = j.optString("sender").trim()
                    val body = j.optString("body").trim()
                    if (sender.isEmpty() || body.isEmpty()) {
                        json(Response.Status.BAD_REQUEST, JSONObject().put("ok", false))
                    } else {
                        val id = db.add(sender.take(50), body.take(500))
                        notifyNew(id, sender, body)
                        json(Response.Status.OK, JSONObject().put("ok", true).put("id", id))
                    }
                }
                s.uri == "/api/requests" -> {
                    val name = s.parms["name"]?.trim()
                    val arr = JSONArray()
                    if (!name.isNullOrEmpty()) db.list(name).forEach {
                        arr.put(JSONObject().put("id", it.id).put("body", it.body)
                            .put("created", it.created).put("status", it.status))
                    }
                    json(Response.Status.OK, arr)
                }
                else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "404")
            }
        } catch (e: Exception) {
            json(Response.Status.INTERNAL_ERROR, JSONObject().put("ok", false))
        }
    }

    companion object {
        fun start(c: Context) {
            val i = Intent(c, ServerService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }

        const val PAGE = """<!DOCTYPE html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>درخواست خدمات</title>
<style>
body{font-family:-apple-system,Tahoma,sans-serif;margin:0;padding:16px;background:#f2f2f7;max-width:600px;margin:auto}
h2{margin:8px 0 16px}
input,textarea{width:100%;box-sizing:border-box;padding:12px;font-size:16px;border:1px solid #ccc;border-radius:10px;margin-bottom:10px;font-family:inherit}
button{width:100%;padding:14px;font-size:17px;border:0;border-radius:10px;background:#0a84ff;color:#fff}
.card{background:#fff;border-radius:12px;padding:12px;margin-top:10px}
.st{display:inline-block;padding:2px 10px;border-radius:12px;font-size:13px;color:#fff}
.new{background:#ff9500}.seen{background:#0a84ff}.done{background:#30b455}
small{color:#777}
#msg{color:#30b455;margin:8px 0;min-height:20px}
</style></head><body>
<h2>ارسال درخواست به خدماتی</h2>
<input id="name" placeholder="نام شما">
<textarea id="body" rows="4" placeholder="درخواست (مثلاً: چای لطفاً)"></textarea>
<button onclick="send()">ارسال</button>
<div id="msg"></div>
<h3>درخواست‌های من</h3>
<div id="list"></div>
<script>
var nameEl=document.getElementById('name');
try{nameEl.value=localStorage.getItem('n')||''}catch(e){}
var L={'new':'ارسال شد','seen':'دیده شد','done':'انجام شد'};
function send(){
  var n=nameEl.value.trim(),b=document.getElementById('body').value.trim();
  if(!n||!b){document.getElementById('msg').textContent='نام و متن را وارد کنید';return}
  try{localStorage.setItem('n',n)}catch(e){}
  fetch('/api/request',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sender:n,body:b})})
  .then(function(r){return r.json()}).then(function(j){
    document.getElementById('msg').textContent=j.ok?'ارسال شد ✓':'خطا';
    if(j.ok){document.getElementById('body').value='';load()}
  }).catch(function(){document.getElementById('msg').textContent='اتصال به گوشی خدماتی برقرار نیست'});
}
function load(){
  var n=nameEl.value.trim();if(!n)return;
  fetch('/api/requests?name='+encodeURIComponent(n)).then(function(r){return r.json()}).then(function(a){
    var box=document.getElementById('list');box.innerHTML='';
    a.forEach(function(x){
      var d=document.createElement('div');d.className='card';
      var t=document.createElement('div');t.textContent=x.body;
      var s=document.createElement('span');s.className='st '+x.status;s.textContent=L[x.status]||x.status;
      var m=document.createElement('small');m.textContent=' '+new Date(x.created).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'});
      d.appendChild(t);d.appendChild(s);d.appendChild(m);box.appendChild(d);
    });
  }).catch(function(){});
}
load();setInterval(load,4000);
</script></body></html>"""
    }
}
